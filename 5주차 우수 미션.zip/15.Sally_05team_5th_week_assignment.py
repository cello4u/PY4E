'''
Q1. 베스킨라빈스31 게임을 만들어봅시다.
'''
# method 1
import random

class LenError(Exception) :
    pass
class FirstnumError(Exception) :
    pass
class ContiError(Exception) :
    pass

## User input function
def user_input(com_turn_num) :
    first_num = com_turn_num[-1] + 1

    for i in range(5) :
        try :
            print("%d부터 최대 3개까지의 연속한 숫자를 입력하세요 : "%(first_num), end="")
            user_turn = input("")
            user_turn_num = user_turn.split()
            user_turn_num = list(map(int, user_turn_num))

            ### Error Check 1 : length
            if not 1 <= len(user_turn_num) <=3 :
                raise LenError

            ### Error Check 2 : firstnum
            if user_turn_num[0] != first_num :
                raise FirstnumError

            ### Error Check 3 : continuous
            if len(user_turn_num) == 2 :
                if (user_turn_num[1] - user_turn_num[0] != 1) :
                    raise ContiError
            elif len(user_turn_num) == 3 :
                if (user_turn_num[2]-user_turn_num[1] != 1) or (user_turn_num[1]-user_turn_num[0] != 1) :
                    raise ContiError

            print("현재 숫자 : %d\n"%(user_turn_num[-1]))
            return user_turn_num

        except LenError :
            print("1개에서 3개까지의 숫자를 다시 입력해주세요.")
        except FirstnumError :
            print("첫 번째 숫자는 1이거나 현재 숫자보다 1만큼만 커야 합니다.")
        except ContiError :
            print("연속한 숫자를 오름차순으로 입력해주세요.")
        except :
            print("다시 입력해주세요.")
    return 1

## Computer input function
def com_input(user_turn_num) :
    com_turn_num = []
    com_turn_count = random.randint(1, 3)
    for i in range(com_turn_count) :
        com_num = user_turn_num[-1] + (i+1)
        com_turn_num.append(com_num)
        print("컴퓨터 : %d"%(com_num))
        if com_num == 31 :
            break

    print("현재 숫자 : %d\n"%(com_turn_num[-1]))

    return com_turn_num

## Game function
def bs31() :
    print("베스킨라빈스 31 게임\n")

    user_turn_num = user_input([0])

    if user_turn_num == 1 :
        print("비정상적 종료")
        return

    while True :
        ### Win condition 1
        if user_turn_num[-1] == 30 :
            print("승리")
            break

        com_turn_num = com_input(user_turn_num)


        ### Win condition 2
        if 31 in com_turn_num :
            print("승리")
            break

        ### Lose condition 1
        if com_turn_num[-1] == 30 :
            print("패배")
            break

        user_turn_num = user_input(com_turn_num)

        if user_turn_num == 1 :
            print("비정상적 종료")
            break

        ### Lose condition 2
        if 31 in user_turn_num :
            print("패배")
            break

bs31()

# method 2

import random
print("베스킨라빈스 31 게임 프로그램입니다!")

## 호출되는 숫자 함수
def call_numbers(size, called):
    for _ in range(size):
        called += 1
        print("'{0}'".format(called))
        if called == 31:
            break
    return called

## 잘못 호출된 숫자 입력시 재입력 하는 함수
def validate_input(prompt, valid_list):
    while True:
        value = input(prompt)
        if value in valid_list:
            value = int(value)
            break
        else:
            print("잘못된 입력입니다. 재입력해주세요.")
    return value

## 컴퓨터가 호출하는 함수
def call_computer(call_status):
    if call_status % 4 == 0:
        computer_call = 2
    elif call_status % 4 == 1:
        computer_call = 1
    elif call_status% 4 == 3:
        computer_call = 3
    else:
        computer_call = random.randint(1, 3)

    return computer_call

## 누가 먼저 호출할지 결정
order = validate_input("순서를 입력하세요. (선공격 1, 후공격 0 입력) : ", ['0', '1'])

call = 0
count = 1

## 사용자는 호출할 숫자의 갯수를 입력함으로써, 게임 진행
while call < 31:
    if count % 2 == order:
        ### 사용자의 차례
        print('사용자의 차례')
        size_of_call = validate_input("호출할 개수를 입력하세요 : ", ['1', '2', '3'])
        call = call_numbers(size_of_call, call)

    else:
        ### 컴퓨터의 차례
        print('컴퓨터의 차례')
        size_of_call = call_computer(call)
        call = call_numbers(size_of_call, call)

    count += 1

if count % 2 == order:
    print("사용자가 승리하셨습니다!!")
else:
    print("컴퓨터의 승리!!")


'''
Q2. 답안지를 채점하고 학생의 점수와 등수를 출력해봅시다.
'''
def grader(students, answers) :
    # split name, submit
    name_ls = []
    submit_ls = []
    for i in range(len(students)) :
        name, submit = students[i].split(',')
        name_ls.append(name)
        submit_ls.append(submit)

    # grade submit
    score_ls = []
    for i in range(len(students)) :
        score_ls.append(0)
        for j in range(len(submit_ls[i])) :
            if submit_ls[i][j] == " " :
                continue
            if int(submit_ls[i][j]) == answers[j] :
                score_ls[i] += 10


    # sort grade
    tmp_ls = list(sorted(zip(score_ls, name_ls))) # 점수를 기준으로 오름차순 정렬
    tmp_ls.reverse() # 리스트를 역순으로 정렬 = 내림차순 정렬
    score_ls, name_ls = zip(*tmp_ls) # zip을 풀어서 score와 name으로 분리

    # rank considering same grade
    rank = list(range(1, len(score_ls)+1))
    for i in range(len(score_ls)-1) :
        if score_ls[i] == score_ls[i+1] :
            rank[i+1] = rank[i]

    for i in range(len(score_ls)) :
        print("학생 : %s, 점수 : %d, 등수 : %d"%(name_ls[i], score_ls[i], rank[i]))

s = ["김갑,3242524215",
"이을,3242524223",
"박병,2242554131",
"최정,4245242315",
"정무,3242524315",
"다운,3242524315",
"운다,324 52431"]

a = [3,2,4,2,5,2,4,3,1,2]

grader(s, a)

'''
Q3. 숫자 맞추기 게임을 만들어봅시다.
'''
# method 1
import random

class RangeError(Exception) :
    pass
class SameError(Exception) :
    pass

## computer selects three numbers
def com_select() :
    com_select_set = set()

    while True :
        number = random.randint(0, 100)
        com_select_set.add(number)

        if len(com_select_set) == 3 :
            break
    return com_select_set

## Game function
def guess_numbers() :
    guess_ls = []
    i, success =1, 0
    print("0부터 100까지의 숫자가 있습니다.")
    print("컴퓨터가 선택한 3개의 숫자를 맞춰주세요.")
    print("힌트는 5차 시도와 10차 시도에 주어집니다.")

    answer_set = com_select()

    while success < 3 :
        print("%d차 시도"%(i))

        ### user selects a number
        try :
            guess = input("컴퓨터가 선택한 숫자를 예측해보세요 : ")
            guess = int(guess)

            if (guess > 100) or (guess < 0) :
                raise RangeError
            if (i>1) and (guess in guess_ls) :
                raise SameError

            guess_ls.append(guess)
            guess_ls.sort()

            print(f"지금까지 {guess_ls}를 입력했습니다.")

        except RangeError :
            print("0부터 100까지의 숫자 중 하나를 입력하세요.")
            continue
        except SameError :
            print("이미 예측에 사용한 숫자입니다. 다시 입력하세요")
            continue
        except :
            print("숫자를 다시 입력하세요.")
            continue

        if guess == max(answer_set) :
            print("숫자를 맞추셨습니다. %d은(는) 최댓값입니다."%(guess))
            success = success + 1
            i+=1
            continue
        elif guess == min(answer_set) :
            print("숫자를 맞추셨습니다. %d은(는) 최솟값입니다."%(guess))
            success = success + 1
            i+=1
            continue
        elif (guess in answer_set) and ( (guess-max(answer_set)) * (guess-min(answer_set)) != 0 ) :
            print("숫자를 맞추셨습니다. %d은(는) 중간값입니다."%(guess))
            success = success + 1
            i+=1
            continue

        if (i == 5) and (guess not in answer_set) :
            if (guess-max(answer_set)) * (guess-min(answer_set)) < 0 :
                print("최솟값과 최댓값 사이의 숫자를 입력했습니다.")
            else :
                print("최솟값과 최댓값 사이에 있지 않은 숫자를 입력했습니다.")
            print("힌트가 1개 남았습니다.")
        elif (i == 10) and (guess not in answer_set) :
            if (guess-max(answer_set)) * (guess-min(answer_set)) < 0 :
                print("최솟값과 최댓값 사이의 숫자를 입력했습니다.")
            else :
                print("최솟값과 최댓값 사이에 있지 않은 숫자를 입력했습니다.")
            print("힌트를 모두 사용했습니다.")
        i+=1

    print("%d번 만에 예측 성공!!"%(i-1))

guess_numbers()

# method 2
import random

random_number= []

while len(random_number)<3: # 숫자 3개 무작위 지정
    number = random.randint(0,100) #무작위 숫자 0~100
    if number not in random_number :
        random_number.append(number)

random_number.sort() #리스트 정렬 sort

answer_count = 0
guess_count = 1
guess_list = []

while answer_count < 3:
    print(f"{guess_count}차 시도")
    answer = int(input("숫자를 예측해보세요 : "))
    if answer in guess_list :
        print("이미 사용된 숫자입니다")
    else:
        guess_list.append(answer)

    if answer in random_number :
        print("숫자를 맞추셨습니다.")
        answer_count = answer_count+1
        if (random_number.index(answer) == 0):
            print(f"{answer}는 최소값입니다.")
        elif (random_number.index(answer) == 1):
            print(f"{answer}는 중간값입니다.")
        elif (random_number.index(answer) == 2):
            print(f"{answer}는 최대값입니다.")
        else:
            print(f"{answer}는 없습니다")

    if guess_count == 5 :
        if random_number[0] <answer:
            print(f"최소값은 {answer}보다 {answer-random_number[0]} 작습니다.")
        else:
            print(f"최소값은 {answer}보다 {random_number[0]-answer} 큽니다.")
    if guess_count == 10 :
        if random_number[2] <answer:
            print(f"최대값은 {answer}보다 {answer-random_number[2]} 작습니다.")
        else:
            print(f"최대값은 {answer}보다 {random_number[2]-answer} 큽니다.")

    guess_count = guess_count + 1


'''
Q4. 100일 뒤가 몇월 며칠인지 계산해주는 함수를 만들어봅시다.
'''
class MonthError(Exception) :
    pass
class DateError(Exception) :
    pass
class DayError(Exception) :
    pass

# 오늘 날짜를 입력받는 함수
def user_input() :
    for i in range(5) :
        try :
            month = int(input("오늘은 몇월입니까?"))

            if month not in range(1, 13) :
                raise MonthError

        except ValueError :
            print("숫자를 입력해주세요.")
            continue
        except MonthError :
            print("오늘 날짜를 확인해주세요.")
            continue
        except :
            print("날짜를 제대로 입력해주세요.")
            continue

        try :
            date = int(input("오늘은 며칠입니까?"))

            if (date < 0) or (date > 31) :
                raise DateError

        except ValueError :
            print("숫자를 입력해주세요.")
            continue
        except DateError :
            print("오늘 날짜를 확인해주세요.")
            continue
        except :
            print("날짜를 제대로 입력해주세요.")
            continue

        try :
            day = input("오늘은 무슨 요일입니까?")

            if day not in ['월', '화', '수', '목', '금', '토', '일'] :
                raise DayError

        except DayError :
            print("오늘 요일을 확인해주세요.")
            continue
        except :
            print("날짜와 요일을 제대로 입력해주세요.")
            continue

        # 정상 작동
        return month, date, day

    # 5번의 입력을 권했을 때에도 오류가 있을 때의 리턴
    return 0, 0, 0

# 100일째 되는 날을 계산하는 함수
def after_100(month, date, day) :
    # 사용자 입력이 잘못되었을 경우
    if (month == 0) and (date == 0) and (day == 0) :
        print("비정상적 종료")
        return

    month_ls = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    day_ls = ['월', '화', '수', '목', '금', '토', '일']

    d_day = 99

    # 100일째 되는 날의 요일 구하기
    after_day_index = day_ls.index(day) + ((d_day) % 7)
    if after_day_index > 6 :
        after_day_index = after_day_index - 7
    after_day = day_ls[after_day_index]

    # 오늘을 포함하는 달은 직접 D-day에서 차감
    d_day = d_day - (month_ls[month-1] - date)
    after_month = month + 1
    if after_month > 12 :
        after_month = after_month - 12

    # 남은 날은 반복문을 이용하여 D-day에서 차감
    while d_day > month_ls[after_month-1] :
        d_day = d_day - month_ls[after_month-1]
        after_month = after_month + 1
        if after_month == 13 :
            after_month = after_month - 12
            print(after_month)

    after_date = d_day

    print("%d월 %d일 %s요일로부터 100일째 되는 날은 %d월 %d일 %s요일입니다." %(month, date, day, after_month, after_date, after_day))

month, date, day = user_input()
after_100(month, date, day)
